<?php
/**
 * Created by PhpStorm.
 * User: HILARIWEB
 * Date: 17/11/2022
 * Time: 08:04
 */
header('Location: web');